import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.Scanner;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

public class APITest {
	
	public static void main(String Args[]) {
		Scanner scan = new Scanner(System.in);
		while(true) {
			System.out.println("Enter the cooresponding number from the below options");
			System.out.println("1 - Find Capital using the country code");
			System.out.println("2 - Find Capital using the country name");
			System.out.println("3- Exit");
			int options = scan.nextInt();
			switch(options) {
				case  1:
					String code="";
					while(true) {
						System.out.print("Enter 2 or 3 letter country code:");
						code = scan.next();
						if(code.length() != 2 && code.length() != 3 ) {
							System.out.println("Please check the country code again. The Code should be either 2 Charecters or 3 charecters only ");
						}
						else if(!code.matches("^[a-zA-Z]*$")) {
							System.out.println("Country code should contain alphabets only");
						}
						else break;
					}
					findCapital(true,code); 
					break;
				case 2:
					String name="";
					while(true) {
						System.out.print("Enter the country name:");
						name = scan.next();
						if(!name.matches("^[a-zA-Z]*$")) {
							System.out.println("Country name should contain alphabets only");
						}
						else break;
					}
					findCapital(false,name); 
					break;
				case 3:
					System.exit(0);
					break;
				default: 
					System.out.println("Choose the valid option from the list.");
					break;
			}
		}
	}

	public static void findCapital(boolean iscode,String value) {

		String output = "";
		try {
			
			URL url = iscode? new URL("https://restcountries.eu/rest/v2/alpha/"+value) :new URL("https://restcountries.eu/rest/v2/name/"+value) ;
			HttpURLConnection conn = (HttpURLConnection) url.openConnection();
			conn.setRequestMethod("GET");
			conn.setRequestProperty("Accept", "application/json");
			conn.connect();
			if(conn.getResponseCode() == 404) {
				System.out.println(iscode? "Please check the Country code - No results Found": "Please check the country Name - No results Found");
				return;
			}
			else if (conn.getResponseCode() != 200) {
				throw new RuntimeException("Failed : HTTP error code : " + conn.getResponseCode());
			} else {

				Scanner sc = new Scanner(url.openStream());
				while (sc.hasNext()) {
					output += sc.nextLine();
				}
				sc.close();
			}
			conn.disconnect();

		} catch (MalformedURLException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}

		JSONParser jsonParser = new JSONParser();
		try {
			if(iscode) {
				JSONObject jobj = (JSONObject) jsonParser.parse(output);
				System.out.println("Capital city of the "+jobj.get("name")+" is "+jobj.get("capital"));
			}
			else {
				JSONArray jobj = (JSONArray) jsonParser.parse(output);
				for(Object obj1 : jobj) {
					JSONObject jsonObject = (JSONObject) obj1;
					System.out.println("Capital city of the "+jsonObject.get("name")+" is "+jsonObject.get("capital"));
				}
			}
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
